package com.vishwajeeth.medicinetime;

/**
 * Created by vishwajeeth on 12/07/17.
 */

public interface BaseView<T> {

    void setPresenter(T presenter);
}
